import sqlite3

def get_db_connection():
    conn = sqlite3.connect('jadwal_lab.db')
    conn.row_factory = sqlite3.Row
    return conn

def ambil_semua_ruangan():
    conn = get_db_connection()
    res = conn.execute('SELECT * FROM tb_ruangan').fetchall()
    conn.close()
    return res

def ambil_semua_mk():
    conn = get_db_connection()
    res = conn.execute('SELECT * FROM tb_matakuliah').fetchall()
    conn.close()
    return res

# FUNGSI BARU UNTUK INPUT DARI WEB
def tambah_ruangan(nama, kapasitas):
    conn = get_db_connection()
    conn.execute('INSERT INTO tb_ruangan (nama_ruangan, kapasitas) VALUES (?, ?)', (nama, kapasitas))
    conn.commit()
    conn.close()

def tambah_mk(nama, dosen, mhs, sks):
    conn = get_db_connection()
    conn.execute('INSERT INTO tb_matakuliah (nama_mk, dosen_pengampu, jumlah_mhs, sks) VALUES (?, ?, ?, ?)', 
                 (nama, dosen, mhs, sks))
    conn.commit()
    conn.close()

def hapus_semua_data():
    conn = get_db_connection()
    conn.execute('DELETE FROM tb_ruangan')
    conn.execute('DELETE FROM tb_matakuliah')
    conn.commit()
    conn.close()