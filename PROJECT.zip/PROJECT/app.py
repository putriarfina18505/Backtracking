from flask import Flask, render_template, request, redirect
from database import ambil_semua_ruangan, ambil_semua_mk, tambah_ruangan, tambah_mk, hapus_semua_data
from logic.algoritma import proses_backtracking

app = Flask(__name__)

@app.route('/')
def index():
    # Mengambil data ruangan dan mata kuliah dari database
    ruangan = ambil_semua_ruangan()
    mk = ambil_semua_mk()
    return render_template('index.html', ruangan=ruangan, mk=mk)

@app.route('/add_ruangan', methods=['POST'])
def add_ruangan():
    nama = request.form['nama_ruangan']
    kapasitas = request.form['kapasitas']
    tambah_ruangan(nama, kapasitas)
    return redirect('/')

@app.route('/add_mk', methods=['POST'])
def add_mk():
    nama = request.form['nama_mk']
    dosen = request.form['dosen']
    mhs = request.form['mhs']
    sks = request.form['sks']
    tambah_mk(nama, dosen, mhs, sks)
    return redirect('/')

@app.route('/reset', methods=['POST'])
def reset():
    # Menghapus semua data dari database sqlite
    hapus_semua_data()
    return redirect('/')

@app.route('/generate', methods=['POST'])
def generate():
    data_mk = ambil_semua_mk()
    data_ruangan = ambil_semua_ruangan()
    
    # Menjalankan algoritma backtracking
    hasil = proses_backtracking(data_mk, data_ruangan)
    
    # Pastikan variabel yang dikirim ke template adalah 'jadwal'
    return render_template('hasil.html', jadwal=hasil)

if __name__ == '__main__':
    # Memperbaiki tanda koma yang salah pada kode sebelumnya
    app.run(debug=True)