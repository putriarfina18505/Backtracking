# logic/algoritma.py

def is_valid(mk, ruangan, hari, jam, jadwal_sementara):
    for j in jadwal_sementara:
        # Cek Bentrok Ruangan di waktu yang sama
        if (j['hari'] == hari and j['jam'] == jam and j['ruangan_id'] == ruangan['id']):
            return False
        # Cek Bentrok Dosen di waktu yang sama
        if (j['hari'] == hari and j['jam'] == jam and j['dosen_nama'] == mk['dosen_pengampu']):
            return False
    return True

def solve_backtracking(mk_list, ruangan_list, slot_waktu, jadwal_sementara):
    if not mk_list:
        return jadwal_sementara
    
    mk_sekarang = mk_list[0]
    sisa_mk = mk_list[1:]
    
    for hari in slot_waktu['hari']:
        for jam in slot_waktu['jam']:
            for r in ruangan_list:
                if is_valid(mk_sekarang, r, hari, jam, jadwal_sementara):
                    jadwal_baru = {
                        'mk_id': mk_sekarang['id'],
                        'mk_nama': mk_sekarang['nama_mk'],
                        'dosen_nama': mk_sekarang['dosen_pengampu'],
                        'ruangan_id': r['id'],
                        'ruangan': r['nama_ruangan'],
                        'hari': hari,
                        'jam': jam
                    }
                    hasil = solve_backtracking(sisa_mk, ruangan_list, slot_waktu, jadwal_sementara + [jadwal_baru])
                    if hasil is not None:
                        return hasil
    return None

def proses_backtracking(data_mk, data_ruangan):
    mk_list = [dict(row) for row in data_mk]
    ruangan_list = [dict(row) for row in data_ruangan]
    
    # Slot waktu diperbanyak agar pasti muat
    slot_waktu = {
        'hari': ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat'],
        'jam': ['08:00-10:00', '10:00-12:00', '13:00-15:00', '15:00-17:00']
    }
    
    return solve_backtracking(mk_list, ruangan_list, slot_waktu, [])